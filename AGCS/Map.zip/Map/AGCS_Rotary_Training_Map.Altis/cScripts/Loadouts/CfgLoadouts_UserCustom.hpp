/* This file is for mission makers to set up Custom Loadouts for players.
    
    Here is a copy paste friendly empty template:

class My_Soldier_Classname_or_VariableName: CommonBlufor {
    //regiment = "";
    //company = "";

    //displayName = "";
    //scope = 0;
    //category[] = {"cScripts_Loadout_Cat_Other"};
    //loadout = [[],[],[],[],[],[],"","",[],["","","","","",""]];
    //insignia = "";

    //abilityMedic = 0;
    //abilityEngineer = 0;
    //abilityEOD = 0;

    //preLoadout = "";
    //postLoadout = "";
};
*/
