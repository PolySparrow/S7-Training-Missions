#define PREFIX cScripts
#define VERSION "4.5.19"

// Uncomment to enable debug mode
//#define DEBUG_MODE

#include "script_macros.hpp"
