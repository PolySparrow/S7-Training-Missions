class rScripts {
	class aa {
		file = "rScripts\functions\aa";
		class aa_spawner {};
	};
	class ga {
		file = "rScripts\functions\ga";
		class ga_cleanup {};
		class ga_findsuitablespot {};
		class ga_patrol {};
		class ga_placer {};
		class ga_spawnloop {};
		class ga_spawnmanager {};
		class ga_spawnunit {};
	};
	class ifr {
		file = "rScripts\functions\ifr";
		class ifr_end {};
		class ifr_placer {};
		class ifr_start {};
		class ifr_weather_loop {};
	};
	class slinglz {
		file = "rScripts\functions\slinglz";
		class slinglz_act {};
		class slinglz_deact {};
		class slinglz_placer {};
		class slinglz_startaction {};
	};
	class tightlz {
		file = "rScripts\functions\tightlz";
		class tightlz_deact {};
		class tightlz_placer {};
		class tightlz_startaction {};
	};
	class utility {
		file = "rScripts\functions\utility";
		class smoke_maker {};
		class turnofflights {};
	};
	class mission {
		file = "rScripts\functions\mission";

	};
	class vicid {
		file = "rScripts\functions\vicid";
		class vic_display{};
		class vic_startaction{};
	};
};