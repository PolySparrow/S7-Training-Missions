#define PREFIX rScripts
#define VERSION "DEVBUILD"
#define DEBUG_MODE

#include "script_macros.hpp"